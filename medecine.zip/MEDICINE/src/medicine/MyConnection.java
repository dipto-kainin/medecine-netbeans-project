/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicine;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.*;
/**
 *
 * @author Admin
 */
public class MyConnection {
    Connection con;
    PreparedStatement x;
    Statement y;
    MyConnection(String schema_name,String password) throws Exception{
        Class.forName ("com.mysql.cj.jdbc.Driver");
        this.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+schema_name+"?useSSL=false","root",password);
    }
    MyConnection(String schema_name,String root,String password) throws Exception{
        Class.forName ("com.mysql.cj.jdbc.Driver");
        this.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+schema_name+"?useSSL=false",root,password);
    }
    
    static void setObjectParameter(PreparedStatement preparedStatement, int index, Object value) throws SQLException {
    // Set the appropriate parameter based on the type of the value
        switch (value.getClass().getSimpleName()) {
            case "Integer" -> preparedStatement.setInt(index, (Integer) value);
            case "String" -> preparedStatement.setString(index, (String) value);
            case "Double" -> preparedStatement.setDouble(index, (Double) value);
            case "byte[]" -> preparedStatement.setBytes(index, (byte[]) value);
            case "Date" -> preparedStatement.setDate(index, new java.sql.Date(((java.util.Date) value).getTime()));
            default -> throw new SQLException("Unsupported data type: " + value.getClass().getSimpleName());
        }
        // Add more cases for other data types as needed
    }         
    boolean preStatement(String pst,Object[] x) throws Exception{
        this.x = this.con.prepareStatement(pst);
        for(int i=0;i<x.length;i++){
            setObjectParameter(this.x,i+1,x[i]);
        }
        return this.x.executeUpdate()>=1;
    }
    ResultSet statement(String pst) throws Exception{
        y = con.createStatement();
        return y.executeQuery(pst);
    }
    void Close(){
        try{
        this.con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    } 
}
/**
 *
 * @author Admin
 */